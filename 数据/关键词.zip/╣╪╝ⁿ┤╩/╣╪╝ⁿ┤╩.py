import jieba
import pandas as pd
import jieba.analyse

stopwords=[stop.strip() for stop in open('stopwords.txt',encoding='UTF-8').readlines()]
f=pd.read_excel("sentence.xlsx", header=0)
corpus=[]
for text in list(f['content']):
    x=text.replace('\t','').replace('\n','').lower()
    segment_words = jieba.cut(x.strip(), cut_all=False)
    result = ''
    for word in segment_words:
        if word not in stopwords and word != ' ':
            result += word
            result += " "
    result=jieba.analyse.extract_tags(sentence=result,topK=15,allowPOS=('ns','nt','nz','n','eng'))
    key='|'.join(result)
    corpus.append(key)
data=[[list(f['id'])[i],corpus[i]] for i in range(len(corpus))]
name=['id','keyword']
test=pd.DataFrame(columns=name,data=data)
print(test)
test.to_excel('keyword.xlsx',index=False);


